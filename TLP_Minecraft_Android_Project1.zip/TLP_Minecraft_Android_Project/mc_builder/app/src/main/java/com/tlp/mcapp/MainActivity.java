package com.tlp.mcapp;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private DownloadManager downloadManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<Long, String> activeFiles = new HashMap<>();
    private static final String PREFS = "downloads";
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private File getDownloadFile(String filename) {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) return null;
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, sanitize(filename));
    }

    private String sanitize(String name) {
        if (name == null || name.trim().isEmpty()) name = "minecraft_file.mcaddon";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return name.length() > 180 ? name.substring(0, 180) : name;
    }

    private String mimeFor(String filename) {
        String n = filename.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".mcworld") || n.endsWith(".mcpack") || n.endsWith(".mcaddon")) return "application/octet-stream";
        if (n.endsWith(".apk")) return "application/vnd.android.package-archive";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    private void sendJs(String js) {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private void sendProgress(String filename, int percent, String status) {
        String safe = filename.replace("\\", "\\\\").replace("'", "\\'");
        String safeStatus = status.replace("\\", "\\\\").replace("'", "\\'");
        sendJs("window.nativeDownloadProgress && window.nativeDownloadProgress('" + safe + "'," + percent + ", '" + safeStatus + "');");
    }

    private void monitorDownload(long downloadId, String filename) {
        activeFiles.put(downloadId, filename);
        handler.post(new Runnable() {
            @Override public void run() {
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(downloadId);
                Cursor cursor = null;
                try {
                    cursor = downloadManager.query(query);
                    if (cursor != null && cursor.moveToFirst()) {
                        int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                        long soFar = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                        int percent = total > 0 ? (int) Math.max(0, Math.min(100, (soFar * 100L) / total)) : 0;

                        if (status == DownloadManager.STATUS_SUCCESSFUL) {
                            activeFiles.remove(downloadId);
                            sendProgress(filename, 100, "complete");
                            return;
                        }
                        if (status == DownloadManager.STATUS_FAILED) {
                            activeFiles.remove(downloadId);
                            sendProgress(filename, -1, "failed");
                            return;
                        }
                        sendProgress(filename, percent, "downloading");
                        handler.postDelayed(this, 250);
                    } else {
                        activeFiles.remove(downloadId);
                        sendProgress(filename, -1, "failed");
                    }
                } finally {
                    if (cursor != null) cursor.close();
                }
            }
        });
    }

    private long getSavedDownloadId(String filename) {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getLong("id_" + sanitize(filename), -1L);
    }

    private void saveDownloadId(String filename, long id) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("id_" + sanitize(filename), id).apply();
    }

    private boolean isDownloadFinished(long id) {
        if (id <= 0) return false;
        Cursor c = null;
        try {
            DownloadManager.Query q = new DownloadManager.Query().setFilterById(id);
            c = downloadManager.query(q);
            if (c != null && c.moveToFirst()) {
                return c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return false;
    }

    private void deleteExistingDownload(String filename) {
        long id = getSavedDownloadId(filename);
        if (id > 0) {
            try { downloadManager.remove(id); } catch (Exception ignored) {}
        }
        File f = getDownloadFile(filename);
        if (f != null && f.exists()) f.delete();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("id_" + sanitize(filename)).apply();
    }

    private void openInMinecraft(String filename) {
        File file = getDownloadFile(filename);
        if (file == null || !file.exists()) {
            Toast.makeText(this, "فایل دانلود شده پیدا نشد.", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri uri = FileProvider.getUriForFile(this, "com.tlp.minecraftapp.fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mimeFor(filename));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setPackage(MINECRAFT_PACKAGE);

        try {
            startActivity(intent);
        } catch (Exception first) {
            try {
                Intent chooser = new Intent(Intent.ACTION_VIEW);
                chooser.setDataAndType(uri, mimeFor(filename));
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(chooser, "باز کردن فایل با..."));
            } catch (Exception second) {
                Toast.makeText(this, "ماینکرفت برای باز کردن این فایل در دسترس نیست.", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean fileExists(String filename) {
            File f = getDownloadFile(filename);
            return f != null && f.exists() && f.length() > 0;
        }

        @JavascriptInterface
        public boolean isFinished(String filename) {
            File f = getDownloadFile(filename);
            if (f != null && f.exists() && f.length() > 0) return true;
            return isDownloadFinished(getSavedDownloadId(filename));
        }

        @JavascriptInterface
        public void startDownload(String url, String filename) {
            runOnUiThread(() -> {
                if (url == null || url.trim().isEmpty()) {
                    sendProgress(filename, -1, "failed");
                    return;
                }

                File file = getDownloadFile(filename);
                if (file != null && file.exists() && file.length() > 0) {
                    sendProgress(filename, 100, "complete");
                    return;
                }

                deleteExistingDownload(filename);

                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setTitle(filename);
                    request.setDescription("در حال دانلود فایل ماینکرفت...");
                    request.setMimeType(mimeFor(filename));
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setAllowedOverMetered(true);
                    request.setAllowedOverRoaming(true);
                    request.setDestinationInExternalFilesDir(MainActivity.this, Environment.DIRECTORY_DOWNLOADS, sanitize(filename));

                    long id = downloadManager.enqueue(request);
                    saveDownloadId(filename, id);
                    sendProgress(filename, 0, "downloading");
                    monitorDownload(id, filename);
                } catch (Exception e) {
                    sendProgress(filename, -1, "failed");
                }
            });
        }

        @JavascriptInterface
        public void openMinecraft(String filename) {
            runOnUiThread(() -> openInMinecraft(filename));
        }

        @JavascriptInterface
        public void deleteFile(String filename) {
            runOnUiThread(() -> deleteExistingDownload(filename));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
